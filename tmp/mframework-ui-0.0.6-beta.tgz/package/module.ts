// @mframework/ui/module.ts
import {
  defineNuxtModule,
  addPlugin,
  addComponentsDir,
  createResolver,
  installModule
} from '@nuxt/kit'

export interface MFrameworkUiOptions {
  image?: Record<string, any>
  fonts?: Record<string, any>
  vuetify?: {
    vuetifyOptions?: Record<string, any>
  }
  tailwind?: {
    enable?: boolean
  }
}

export default defineNuxtModule<MFrameworkUiOptions>({
  meta: {
    name: '@mframework/ui',
    configKey: 'mframeworkUi'
  },
  defaults: {
    image: {},
    fonts: {},
    vuetify: {
      vuetifyOptions: {
        icons: {
          defaultSet: 'mdi'
        }
      }
    },
    tailwind: {
      enable: true
    }
  },
  async setup(options, nuxt) {
    const { resolve } = createResolver(import.meta.url)

    //
    // 1. Expose options to runtime
    //
    nuxt.options.runtimeConfig.public.mframeworkUi = options

    //
    // 2. Install @nuxt/image
    //
    await installModule('@nuxt/image', options.image || {})

    //
    // 3. Install @nuxt/fonts
    //
    await installModule('@nuxt/fonts', options.fonts || {})

    //
    // 4. Install Vuetify via vuetify-nuxt-module (optional).
    //    First check whether the consuming project actually has `vuetify`
    //    installed to avoid Nuxt failing during module resolution.
    //
    let vuetifyInstalled = false
    try {
      // Use Node resolution from this project's root to detect installed package
      // without triggering Nuxt's module loader.
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { createRequire } = await import('module')
      const req = createRequire(import.meta.url)
      try {
        req.resolve('vuetify')
        // Vuetify is present in the project's node_modules. We won't call
        // `installModule` here to avoid forcing Nuxt to load the module
        // during `nuxt prepare` (which can fail in some install environments).
        vuetifyInstalled = true
      } catch (e) {
        // Vuetify not found — skip installing the module
        // eslint-disable-next-line no-console
        console.warn('@mframework/ui: Vuetify not found in project dependencies; skipping Vuetify integration.')
      }
    } catch (err) {
      // If resolution itself fails for any reason, avoid breaking the setup.
      // eslint-disable-next-line no-console
      console.warn('@mframework/ui: Failed to detect Vuetify availability; skipping Vuetify integration.')
      vuetifyInstalled = false
    }

    //
    // 5. Tailwind + Vuetify coexistence
    //
    if (options.tailwind?.enable !== false) {
      nuxt.options.css = nuxt.options.css || []
      nuxt.options.css.push(resolve('./runtime/assets/css/tailwind.css'))

      nuxt.options.postcss = nuxt.options.postcss || { plugins: {}, order: [] }
      nuxt.options.postcss.plugins = nuxt.options.postcss.plugins || {}
      // Use the new PostCSS adapter package name so Nuxt doesn't try to
      // use the old `tailwindcss` package as a PostCSS plugin.
      nuxt.options.postcss.plugins['@tailwindcss/postcss'] = {}
      nuxt.options.postcss.plugins['autoprefixer'] = {}

      nuxt.options.tailwindcss = {
        configPath: resolve('./runtime/assets/config/tailwind.config.cjs')
      }
    }

    //
    // 6. Register plugins (icons, theme, icon switching, search).
    //    Only register plugins that require Vuetify when Vuetify is available.
    //
    if (vuetifyInstalled) {
      addPlugin(resolve('./runtime/plugins/theme'))
      addPlugin(resolve('./runtime/plugins/icon-switcher'))
      addPlugin(resolve('./runtime/search/plugin'))
    } else {
      // If Vuetify isn't installed, we still register a minimal search plugin
      // that doesn't depend on Vuetify, if present. Keep module resilient.
      try {
        addPlugin(resolve('./runtime/search/plugin'))
      } catch (e) {
        // ignore — plugin not critical
      }
    }

    //
    // 7. Auto-import components from this module
    //
    addComponentsDir({
      path: resolve('./runtime/components'),
      pathPrefix: false,
      prefix: 'M'
    })

    addComponentsDir({
      path: resolve('./runtime/search/components'),
      prefix: 'M'
    })
  }
})