import { vuetify } from './vuetify'

export default (nuxtApp: any) => {
  const stored = typeof localStorage !== 'undefined' ? localStorage.getItem('mframework-icon-set') : null
  const initial = stored || 'mdi'

  // `vuetify` typing differs between versions; treat as any here
  ;(vuetify as any).framework = (vuetify as any).framework || {}
  ;(vuetify as any).framework.icons = (vuetify as any).framework.icons || {}
  ;(vuetify as any).framework.icons.defaultSet = initial

  const setIconSet = (name: string) => {
    ;(vuetify as any).framework.icons.defaultSet = name
    if (typeof localStorage !== 'undefined') localStorage.setItem('mframework-icon-set', name)
  }

  nuxtApp.provide('mIcons', {
    setIconSet,
    current: () => (vuetify as any).framework.icons.defaultSet,
  })
}